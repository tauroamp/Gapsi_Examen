package mx.com.grupoasesores.examen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenGapsiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenGapsiApplication.class, args);
	}

}
