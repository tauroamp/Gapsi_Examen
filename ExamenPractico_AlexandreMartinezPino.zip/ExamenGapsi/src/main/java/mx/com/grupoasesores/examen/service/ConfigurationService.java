package mx.com.grupoasesores.examen.service;


public interface ConfigurationService {

    String getVersion();

    String getWelcomeMessage();

}
