class RestUrls {
  static final String host_port = 'http://localhost:8089';

  static final String get_configuraction_url = "${host_port}/configuration";

  static final String get_lista_proveedores_url =
      "${host_port}/proveedores/list";
}
