class ProveedoresService {}
